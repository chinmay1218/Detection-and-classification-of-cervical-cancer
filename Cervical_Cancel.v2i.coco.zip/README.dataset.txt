# Cervical_Cancel > 2022-07-24 12:47am
https://universe.roboflow.com/aimed/cervical_cancel

Provided by a Roboflow user
License: CC BY 4.0

